import traceback
import pandas as pd
import json
import time
import google.generativeai as genai
from datetime import datetime
from shopify_scraper import scrape_shopify_store
from woocommerce_scraper import scrape_woocommerce_store_api

# ===== CONFIGURACIÓN BIGQUERY =====
BQ_PROJECT_ID = "project-5ca89b0c-e364-4245-a61"
BQ_TABLE_ID = "muebles_db.scrapes"
BQ_AGREGAR_HISTORICO = True
# ==================================

# Categorizadas tras analizar / products.json y wp-json/wc
SHOPIFY_STORES = [
    "https://areadesign.cl", "https://tiendaladeco.cl", "https://broca.cl",
    "https://mushkabazar.cl", "https://www.rusticchic.cl", "https://www.theproductculture.cl",
    "https://manifestodesignstore.com", "https://cristian-valdes.com", "https://www.ankataller.com",
    "https://interdesign.cl"
]

WOOCOMMERCE_STORES = [
    "https://leatherhouse.cl", "https://tiendamad.cl", "https://primamuebles.cl",
    "https://sofaroller.cl", "https://www.sofaonline.cl", "https://angelarestrepo.cl"
]

OTHER_STORES = [
    "https://forastero.life", "https://amoble.cl", "https://www.maderistica.cl",
    "https://www.boconcept.com", "https://www.roche-bobois.com"
]

def categorize_products_with_gemini(df, project_id):
    print("\n=== INICIANDO NORMALIZACIÓN CON GEMINI (API KEY LIBRE) ===")
    try:
        genai.configure(api_key="AIzaSyC4pbjuq5EGOBgAGYoGuwgACS5xSxV-gnA")
        model = genai.GenerativeModel("gemini-1.5-flash")
    except Exception as e:
        print(f"No se pudo inicializar Gemini AI Studio. Revisar API Key: {e}")
        return df
        
    unique_products = df[['Nombre de Producto', 'Tipo de Producto', 'Descripcion']].drop_duplicates().reset_index(drop=True)
    print(f"Total de productos únicos a categorizar: {len(unique_products)}")
    
    batch_size = 50
    mappings = {}
    
    for i in range(0, len(unique_products), batch_size):
        batch = unique_products.iloc[i:i+batch_size]
        prompt_data = []
        for idx, row in batch.iterrows():
            prompt_data.append({
                "id": str(idx),
                "nombre": str(row.get('Nombre de Producto', '')),
                "tipo_original": str(row.get('Tipo de Producto', '')),
                "descripcion": str(row.get('Descripcion', ''))
            })
            
        prompt = f"""
Eres un experto categorizador de retail de muebles. 
Toma esta lista JSON de productos y devuelve SOLO un objeto JSON donde cada "id" apunte a una única categoría global estandarizada (ej. "Sofá", "Silla", "Mesa", "Cama", "Lámpara", "Decoración").
No inventes categorías muy específicas, usa conceptos amplios y limpios.
Usa la descripcion para deducir la categoría si es necesario.
Devuelve el JSON puro sin bloques de código Markdown (```).

Entrada:
{json.dumps(prompt_data, ensure_ascii=False)}
"""
        try:
            response = model.generate_content(prompt)
            texto = response.text.replace('```json', '').replace('```', '').strip()
            batch_mapping = json.loads(texto)
            for k, v in batch_mapping.items():
                mappings[k] = v
            print(f"Lote {i//batch_size + 1}/{(len(unique_products)//batch_size)+1} procesado con éxito.")
        except Exception as e:
            print(f"Error procesando lote {i//batch_size + 1}: {e}")
            for k in [str(x) for x in batch.index]:
                mappings[k] = batch.loc[int(k), 'Tipo de Producto']
        
        time.sleep(2)
        
    print("Aplicando categorías normalizadas al catálogo...")
    unique_products['Categoria_IA'] = unique_products.index.astype(str).map(mappings)
    unique_products['Categoria_IA'] = unique_products['Categoria_IA'].fillna(unique_products['Tipo de Producto'])
    
    df = df.merge(unique_products[['Nombre de Producto', 'Tipo de Producto', 'Descripcion', 'Categoria_IA']], 
                  on=['Nombre de Producto', 'Tipo de Producto', 'Descripcion'], 
                  how='left')
    df['Tipo de Producto Original'] = df['Tipo de Producto']
    df['Tipo de Producto'] = df['Categoria_IA']
    df.drop('Categoria_IA', axis=1, inplace=True)
    return df

def main():
    all_data = []
    
    print("=== INICIANDO EXTRACCIÓN DE SHOPIFY ===")
    for url in SHOPIFY_STORES:
        try:
            data = scrape_shopify_store(url)
            all_data.extend(data)
            print(f"[OK] {url} -> {len(data)} productos total.")
        except Exception as e:
            print(f"[ERROR] Falló {url}: {e}")

    print("\n=== INICIANDO EXTRACCIÓN DE WOOCOMMERCE ===")
    for url in WOOCOMMERCE_STORES:
        try:
            data = scrape_woocommerce_store_api(url)
            all_data.extend(data)
            print(f"[OK] {url} -> {len(data)} productos total.")
        except Exception as e:
            print(f"[ERROR] Falló {url}: {e}")
            
    print("\nLas tiendas de plataformas custom/VTEX se han omitido en esta v1 principal por requerir desarrollos dedicados.")

    # Guardar a Excel
    if all_data:
        df = pd.DataFrame(all_data)
        df = df.drop_duplicates(subset=['URL Producto', 'Variacion'])
        
        # --- IA NORMALIZATION ---
        try:
            df = categorize_products_with_gemini(df, BQ_PROJECT_ID)
        except Exception as e:
            print(f"Error general en normalización IA, continuando con datos originales: {e}")
        # ------------------------
        
        output_file = "muebles_chile_data.xlsx"
        df.to_excel(output_file, index=False)
        print(f"\n✅ EXTRACCIÓN FINALIZADA. Archivo guardado: {output_file} con {len(df)} variaciones.")
        
        # Guardar en BigQuery
        print("\n=== INICIANDO EXPORTACIÓN A BIGQUERY ===")
        try:
            # Agregar la fecha de ejecución al registro para diferenciar las semanas
            df['Fecha Scraping'] = datetime.now().strftime('%Y-%m-%d')
            
            if BQ_AGREGAR_HISTORICO:
                comportamiento = 'append'
            else:
                comportamiento = 'replace'
                
            df.to_gbq(
                destination_table=BQ_TABLE_ID, 
                project_id=BQ_PROJECT_ID, 
                if_exists=comportamiento,
                progress_bar=True
            )
            print(f"✅ ¡Datos subidos exitosamente a BigQuery en {BQ_PROJECT_ID}:{BQ_TABLE_ID}!")
        except Exception as e:
            print(f"❌ Error al intentar subir a BigQuery. Asegúrate de que el proyecto '{BQ_PROJECT_ID}' sea válido y de tener permisos: {e}")
            
    else:
        print("No se encontraron datos.")

if __name__ == "__main__":
    main()
