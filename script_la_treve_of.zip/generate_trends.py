import pandas as pd
import os

LA_TREVE_BRANDBOOK = """
Antecedentes: La Trêve nace como una respuesta al mobiliario producido en masa. En un mundo donde los muebles se compran rápidamente y se reemplazan con facilidad, la marca propone lo contrario: tiempo, dedicación y materia. Cada pieza comienza con un diseño pensado para un cliente y un espacio específico. Ese diseño es llevado a manos de maestros carpinteros y ebanistas que lo materializan con precisión artesanal. La Trêve no busca llenar casas con objetos. Busca crear piezas que construyan hogar.
Comportamiento: La marca no busca atención, la merece. No compite, se posiciona. No vende directamente, construye valor. Cada publicación debe sentirse como el producto mismo: medido, trabajado, honesto y duradero.
Misión: Crear muebles de alta gama diseñados con sensibilidad estética y medioambiental construidos artesanalmente por maestros carpinteros y ebanistas, utilizando materiales de primera calidad.
Visión: Posicionarse como una marca referente de mobiliario de autor en Chile y Latinoamérica, reconocida por su diseño, calidad material, carácter artesanal y compromiso con la sustentabilidad.
Identidad: La Trêve representa pausa, intimidad y reconciliación con el espacio doméstico.
Pilares: Artesanía contemporánea. Hogar como refugio. Permanencia material.
Valores centrales: Artesanía, Calidad material, Diseño atemporal, Calidez, Identidad personal, Exclusividad, Sustentabilidad.
Palabras asociadas: materia, oficio, permanencia, diseño, hogar, pausa, detalle, proporción, textura, tiempo.
Lenguaje de marca: La marca habla desde la calma, la precisión y la autoridad silenciosa. No explica de más. Sugiere, demuestra.
Materialidad: madera maciza, veta, textura, densidad, acabado, nobleza.
Oficio: ebanistería, ensamblaje, precisión, proceso, mano, técnica.
Diseño: proporción, equilibrio, detalle, composición.
"""

def main():
    print("Cargando el catálogo unificado de muebles extraídos...")
    try:
        df = pd.read_excel("muebles_chile_data.xlsx")
    except Exception as e:
        print("Error al abrir 'muebles_chile_data.xlsx'. Asegúrate de haber corrido main.py primero para tener datos.", e)
        return
        
    categorias_top = df['Tipo de Producto'].value_counts().head(5).index.tolist()
    print(f"Analizaremos el top 5 de categorías del mercado: {categorias_top}")
    
    file_name = "Prompts_Para_ChatGPT_O_Gemini.txt"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write("=== COPIA Y PEGA ESTOS BLOQUES EN CHATGPT O GEMINI GRATUITO ===\n")
        f.write("(La IA a la que se los pegues podrá leer los Links de la competencia y aplicar el Brandbook para diseñar tus Renders)\n\n")
        
        for cat in categorias_top:
            if str(cat).lower() in ['nan', 'none', '']: continue
            subset = df[df['Tipo de Producto'] == cat].dropna(subset=['URL Imagen']).head(15)
            
            f.write(f"======================================\n")
            f.write(f"[ TAREA DE DISEÑO : {cat.upper()} ]\n")
            
            prompt = f"""Actúa como el Director Creativo, Analista de Mercado y Maestro Ebanista de la exclusiva marca de muebles "La Trêve".

A continuación te presento los nombres y los links de las imágenes de los "{cat}" más vendidos en el mercado chileno por nuestros competidores directos. Analiza los links para entender qué está de moda:
"""
            for _, row in subset.iterrows():
                prompt += f"- {row['Nombre de Producto']}: {row['URL Imagen']}\n"
                
            prompt += f"""
Este es el libro de marca (Brandbook) de nuestra empresa:
{LA_TREVE_BRANDBOOK}

TAREA:
1. Analiza brevemente qué está pidiendo el mercado en "{cat}".
2. REIMAGINA este producto usando el ADN estricto de La Trêve (artesanía, madera maciza, proporción, ebanistería fina, atemporalidad, no-viral).
3. REDACTA UN PROMPT EN INGLÉS detallado (máximo 60 palabras) para enviárselo a Midjourney (o DALL-E) que describa una fotografía hiperrealista de la pieza de mobiliario final de La Trêve resultante. Incluye términos como "High-end photography, solid wood craftsmanship, timeless design, cinematic lighting, extreme attention to wood grain".
"""
            f.write(prompt)
            f.write("\n--------------------------------------\n\n")
            
    print(f"✅ ¡Plan B completado! Como los servidores rechazaron el acceso comercial de IA, hemos optado por generar las instrucciones 'offline'.")
    print(f"Se ha creado un archivo de texto llamado '{file_name}' en esta carpeta.")
    print("Simplemente ábrelo, copia el texto y pégalo en la versión gratuita de ChatGPT GPT-4 o en Gemini Web, ellos generarán los diseños por ti usando tus links recopilados.")

if __name__ == "__main__":
    main()
